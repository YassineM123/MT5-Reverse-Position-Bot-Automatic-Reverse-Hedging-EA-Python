# MT5 Reverse-Position Bot

A Python bot that automatically opens and manages reverse positions in MetaTrader 5.
See full README in the ChatGPT conversation.
